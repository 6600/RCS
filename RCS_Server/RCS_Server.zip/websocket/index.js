
require('babel-register');
require('babel-core').transform();
require('./socket/wsocket.js');
//require('./socket/socketCluster');

