require('babel-register');
require('babel-core').transform();
require('./app.js');

