##jest相关教程，
http://www.voidcn.com/article/p-ehpgegvm-bue.html
https://www.npmjs.com/package/jest-websocket-mock


