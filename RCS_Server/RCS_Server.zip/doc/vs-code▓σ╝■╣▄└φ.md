##十款顶级插件。
https://www.cnblogs.com/zhangycun/p/9529623.html



add jsdoc comments  注释插件1
https://blog.csdn.net/skybboy/article/details/82797659

koroFileHeader     快捷注释插件2
https://blog.csdn.net/an_xinyu/article/details/88737158



 Error occured while trying to proxy to: localhost:8081
https://blog.csdn.net/jack_yangying/article/details/79536106



Vue打包部署到window sever 服务端：
https://www.cnblogs.com/zypblogs/p/11250744.html       scp2 自动上传
https://www.cnblogs.com/badaoliumangqizhi/p/13297929.html


windowserver 2012安装openssh
github https://github.com/PowerShell/Win32-OpenSSH/releases
https://www.cnblogs.com/ddif/p/10020454.html


mysqld --install mysql --defaults-file=C:\Program Files (x86)\mysql-8.0.19-winx64\my.ini
 


ALTER USER 'root'@'localhost' IDENTIFIED BY 'password' PASSWORD EXPIRE NEVER
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '123456'