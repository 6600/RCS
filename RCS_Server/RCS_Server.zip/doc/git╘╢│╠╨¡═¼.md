sourcetree git 设置 码云
https://blog.csdn.net/a133900029/article/details/82357128
关联好码云账号后，设置---》远程仓库：添加自己的仓库地址


忽略nodemoudle 文件  设置  -->高级---》编辑-->添加忽略文件
https://blog.csdn.net/weixin_43911969/article/details/107216166

提交 推送 拉取 区别
https://blog.csdn.net/qq_22873427/article/details/82985159

git生成ssh key 避免每次push都要输入账号密码
https://www.cnblogs.com/lxwphp/p/9590905.html

如何将本地项目上传到Github
http://www.downza.cn/xy/48544.html


